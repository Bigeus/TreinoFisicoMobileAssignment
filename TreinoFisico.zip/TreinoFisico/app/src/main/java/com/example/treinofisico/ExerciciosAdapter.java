package com.example.treinofisico;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class ExerciciosAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<Exercicio> exerciciosList;
    private LayoutInflater inflater;

    public ExerciciosAdapter(Context context, ArrayList<Exercicio> exerciciosList) {
        this.context = context;
        this.exerciciosList = exerciciosList;
        this.inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return exerciciosList.size();
    }

    @Override
    public Object getItem(int position) {
        return exerciciosList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_exercicio, parent, false);
        }

        // Referências para os campos de nome e duração
        TextView nomeExercicio = convertView.findViewById(R.id.nomeExercicio);
        TextView duracaoExercicio = convertView.findViewById(R.id.duracaoExercicio);

        // Obtém o exercício da lista
        Exercicio exercicio = exerciciosList.get(position);

        // Configura os valores na interface
        nomeExercicio.setText(exercicio.getNome());
        duracaoExercicio.setText(exercicio.getDuracao() + "s");

        return convertView;
    }
}
