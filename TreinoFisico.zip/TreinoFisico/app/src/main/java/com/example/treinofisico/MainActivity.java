package com.example.treinofisico;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private TextView contadorText;
    private Button iniciarTreinoBtn;
    private Button adicionarExercicioBtn;  // Botão para adicionar exercício
    private ListView listaExercicios;
    private ArrayList<Exercicio> exerciciosList = new ArrayList<>();
    private ExerciciosAdapter exerciciosAdapter;
    private int currentExerciseIndex = 0;
    private CountDownTimer countDownTimer;

    private static final int CADASTRO_EXERCICIO_REQUEST_CODE = 1;  // Constante para a solicitação

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        contadorText = findViewById(R.id.contadorText);
        iniciarTreinoBtn = findViewById(R.id.iniciarTreinoBtn);
        adicionarExercicioBtn = findViewById(R.id.adicionarExercicioBtn);  // Botão para adicionar exercício
        listaExercicios = findViewById(R.id.listaExercicios);

        // Exemplo de exercícios cadastrados
        exerciciosList.add(new Exercicio("Agachamento", 30));
        exerciciosList.add(new Exercicio("Flexão", 20));
        exerciciosList.add(new Exercicio("Descanso", 10));

        // Configurar a lista de exercícios na tela
        exerciciosAdapter = new ExerciciosAdapter(this, exerciciosList);
        listaExercicios.setAdapter(exerciciosAdapter);

        // Configurar o botão "Iniciar Treino"
        iniciarTreinoBtn.setOnClickListener(v -> iniciarTreino());

        // Configurar o botão "Adicionar Exercício"
        adicionarExercicioBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CadastroExercicio.class);
            startActivityForResult(intent, CADASTRO_EXERCICIO_REQUEST_CODE);  // Abrir a tela de cadastro de exercício
        });
    }

    private void iniciarTreino() {
        if (exerciciosList.size() > 0) {
            currentExerciseIndex = 0;  // Garantir que o treino sempre comece do primeiro exercício
            iniciarExercicio(exerciciosList.get(currentExerciseIndex));  // Inicia o primeiro exercício
        } else {
            Toast.makeText(this, "Adicione exercícios primeiro!", Toast.LENGTH_SHORT).show();
        }
    }

    private void iniciarExercicio(Exercicio exercicio) {
        // Exibe o tempo exato do exercício (sem ajuste)
        contadorText.setText(String.valueOf(exercicio.getDuracao()));

        // Inicia o contador de tempo, com uma pequena alteração para compensar qualquer atraso
        new CountDownTimer(exercicio.getDuracao() * 1000 + 1000, 1000) {  // Acrescenta 1000ms (1 segundo) ao tempo

            @Override
            public void onTick(long millisUntilFinished) {
                // Exibe o tempo correto no contador
                contadorText.setText(String.valueOf(millisUntilFinished / 1000));
            }

            @Override
            public void onFinish() {
                // Quando o tempo acabar, passa para o próximo exercício
                currentExerciseIndex++;  // Avança para o próximo exercício
                if (currentExerciseIndex < exerciciosList.size()) {
                    Exercicio proximoExercicio = exerciciosList.get(currentExerciseIndex);
                    iniciarExercicio(proximoExercicio);  // Inicia o próximo exercício
                } else {
                    // Se todos os exercícios terminarem, finaliza o treino
                    NotificationUtils.showNotification(MainActivity.this, "Treino concluído! Parabéns!");
                    Toast.makeText(MainActivity.this, "Treino finalizado!", Toast.LENGTH_SHORT).show();
                    currentExerciseIndex = 0; // Reseta o índice para o começo da lista
                }
            }
        }.start();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CADASTRO_EXERCICIO_REQUEST_CODE && resultCode == RESULT_OK) {
            Exercicio novoExercicio = (Exercicio) data.getSerializableExtra("exercicio");
            if (novoExercicio != null) {
                exerciciosList.add(novoExercicio);
                exerciciosAdapter.notifyDataSetChanged();
                Toast.makeText(this, "Exercício adicionado!", Toast.LENGTH_SHORT).show();
            }
        }
    }

}
