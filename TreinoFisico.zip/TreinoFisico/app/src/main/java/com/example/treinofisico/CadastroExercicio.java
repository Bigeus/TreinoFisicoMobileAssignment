package com.example.treinofisico;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class CadastroExercicio extends AppCompatActivity {

    private EditText nomeExercicioEdit;
    private EditText duracaoExercicioEdit;
    private Button salvarBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_exercicio);

        nomeExercicioEdit = findViewById(R.id.nomeExercicioEdit);
        duracaoExercicioEdit = findViewById(R.id.duracaoExercicioEdit);
        salvarBtn = findViewById(R.id.salvarBtn);

        salvarBtn.setOnClickListener(v -> salvarExercicio());
    }

    private void salvarExercicio() {
        String nome = nomeExercicioEdit.getText().toString();
        String duracaoStr = duracaoExercicioEdit.getText().toString();

        if (nome.isEmpty() || duracaoStr.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
            return;
        }

        int duracao = Integer.parseInt(duracaoStr);

        // Salvar o exercício na lista de exercícios ou no banco de dados
        Exercicio novoExercicio = new Exercicio(nome, duracao);

        // Pode adicionar à lista de exercícios ou persistir no banco de dados
        Intent resultIntent = new Intent();
        resultIntent.putExtra("exercicio", novoExercicio);
        setResult(RESULT_OK, resultIntent);
        finish();
    }
}
